The following lines were used to generate the test files via the instructor's
sample solution:

./schedprint --start=11/10/2013 --end=12/10/2013 --file=deborah_developer.ics > test01.txt
./schedprint --start=5/11/2013 --end=11/11/2013 --file=deborah_developer.ics > test02.txt
./schedprint --start=30/10/2013 --end=30/10/2013 --file=deborah_developer.ics > test03.txt
./schedprint --start=01/01/2013 --end=31/12/2013 --file=deborah_developer.ics > test04.txt
./schedprint --start=01/01/2013 --end=31/12/2013 --file=deborah_developer.ics > test05.txt
./schedprint --start=31/10/2013 --end=31/10/2013 --file=deborah_developer.ics > test06.txt
./schedprint --start=1/11/2013 --end=30/11/2013 --file=deborah_developer.ics > test07.txt
./schedprint --start=1/12/2013 --end=31/12/2013 --file=deborah_developer.ics > test08.txt
./schedprint --start=8/9/2013 --end=3/12/2013 --file=deborah_developer.ics > test09.txt
./schedprint --start=28/9/2013 --end=25/9/2013 --file=deborah_developer.ics > test10.txt
./schedprint --start=11/10/2013 --end=12/10/2013 --file=nhl_canada.ics > test11.txt
./schedprint --start=5/11/2013 --end=11/11/2013 --file=nhl_canada.ics > test12.txt
./schedprint --start=30/10/2013 --end=30/10/2013 --file=nhl_canada.ics > test13.txt
./schedprint --start=01/01/2013 --end=31/12/2013 --file=nhl_canada.ics > test14.txt
./schedprint --start=01/01/2013 --end=31/12/2013 --file=nhl_canada.ics > test15.txt
./schedprint --start=31/10/2013 --end=31/10/2013 --file=nhl_canada.ics > test16.txt
./schedprint --start=1/11/2013 --end=30/11/2013 --file=nhl_canada.ics > test17.txt
./schedprint --start=1/12/2013 --end=31/12/2013 --file=nhl_canada.ics > test18.txt
./schedprint --start=8/9/2013 --end=3/4/2014 --file=nhl_canada.ics > test19.txt
./schedprint --start=28/9/2013 --end=25/9/2013 --file=nhl_canada.ics > test20.txt

Although the locations of files in your account may different, the "--start",
and "--end" values you need to run your tests must be given when you run
your own program from the command line.
